# KPBI Barongsay Android WebView

Android wrapper for https://barongsaisurabaya.github.io/Pendaftaran/

## Build

The GitHub Actions workflow at `.github/workflows/build-apk.yml` builds a debug APK when pushed to `main` or when manually started from Actions.

After a successful run, download the `kpbi-barongsay-apk` artifact and extract `app-debug.apk`.

## Notes

- This is a WebView wrapper and requires internet access.
- The launcher icon and splash artwork are starter vector artwork, not an official KPBI logo. Replace them with approved brand artwork before public distribution.
- File chooser support is included. Camera permission and direct camera-based QR scanning may require additional integration depending on how the website implements those features.
- Debug APK is for testing. A release APK for public distribution should be signed with a private signing key.
